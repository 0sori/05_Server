package edu.kh.community.member.controller;

import javax.servlet.annotation.WebServlet;

@WebServlet("/member/selectAll")
public class SelectAllServlet {
	
}
